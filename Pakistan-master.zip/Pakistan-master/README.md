# Pakistan
Watch The Tutorial

Video Link

https://youtu.be/VgX1LVu2oko

Use These Awessome Commands and Enjoy..

and Don't Forget To Subscribe My Channel 

https://www.youtube.com/c/technicalzahidmahmood
